/**
 * 
 */
package br.etec.main;

import br.etec.bean.Caixa;
import br.etec.bean.GerenteGeral;

/**
 * @author Rayane
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Caixa cx=new Caixa();
        GerenteGeral gg=new GerenteGeral();
   


	}

}
