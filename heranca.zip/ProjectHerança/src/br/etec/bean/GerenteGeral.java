package br.etec.bean;
/**
 * 
 */

/**
 * @author Aluno
 *
 */
public class GerenteGeral extends Gerente {

}
