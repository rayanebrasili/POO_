/**
 * 
 */
package br.etec.bean;

/**
 * @author Rayane
 *
 */
public class Caixa extends Pessoa {
private double salario ;

public double getSalario() {
	return salario;
}

public void setSalario(double salario) {
	      this.salario = salario;
}

}
