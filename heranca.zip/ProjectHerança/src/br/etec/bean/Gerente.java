package br.etec.bean;
/**
 * 
 */

/**
 * @author Aluno
 *
 */
public class Gerente extends Pessoa {

	protected String tipo;

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
}
