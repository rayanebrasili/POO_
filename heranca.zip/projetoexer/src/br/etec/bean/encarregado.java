package br.etec.bean;


	public class encarregado extends pessoa {
		private double salario ;

		public double getSalario() {
			return salario;
		}

		public void setSalario(double salario) {
			this.salario = salario;
		}
	
}
