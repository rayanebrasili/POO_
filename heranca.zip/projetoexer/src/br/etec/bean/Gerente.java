package br.etec.bean;


	public class Gerente extends pessoa {
		public double getSalario() {
			return salario;
		}

		public void setSalario(double salario) {
			this.salario = salario;
		}

		private double salario ;

}
