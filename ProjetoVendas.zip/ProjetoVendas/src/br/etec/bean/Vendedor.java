package br.etec.bean;

public class Vendedor {

	private int codigo;
	private String nome;
	private double salario;
	private double com;
	private double salariofinal;
	private double valorvenda;
	
	
	public double getValorvenda() {
		return valorvenda;
	}
	public void setValorvenda(double valorvenda) {
		this.valorvenda = valorvenda;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public double getCom() {
		return com;
	}
	public double getSalariofinal() {
		return salariofinal;
	}
	
	public void calculocom(double valor,double valordavenda) {
		
   this.valorvenda= valordavenda;
	this.com = this.valorvenda * (valor/100); 	
	}
	public void salariototal() {
		this.salariofinal= this.salario + this.com;
	}
	
}
