package br.etec.bean;

public class Produto {
	   private int codigo;
	   private String produto;
	   public Fornecedor fornecedor;
	   private double valorporc;
	   private double valor;
	   private double valorvenda;
	   

	   
	public int getCodigo() {
		return codigo;
	}



	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}



	public String getProduto() {
		return produto;
	}



	public void setProduto(String produto) {
		this.produto = produto;
	}



	public Fornecedor getFornecedor() {
		return fornecedor;
	}



	public void setFornecedor(Fornecedor fornecedor) {
		this.fornecedor = fornecedor;
	}



	public double getValorporc() {
		return valorporc;
	}



	public void setValorporc(double valorporc) {
		this.valorporc = valorporc;
	}



	public double getValor() {
		return valor;
	}



	public void setValor(double valor) {
		this.valor = valor;
	}



	public double getValorvenda() {
		return valorvenda;
	}



	public void setValorvenda(double valorvenda) {
		this.valorvenda = valorvenda;
	}



	public void calculovalorproduto(double porc) {
		this.valorvenda= this.valor + (this.valor * (porc/100));
	}
}
