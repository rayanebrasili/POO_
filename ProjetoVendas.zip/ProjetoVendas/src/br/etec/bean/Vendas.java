package br.etec.bean;

public class Vendas {

	private int codvenda;
	public Vendedor vendedor;
    public Cliente cliente;
    public Produto produto;
    private double totalvenda;
    
    
	public int getCodvenda() {
		return codvenda;
	}
	public void setCodvenda(int codvenda) {
		this.codvenda = codvenda;
	}
	public double getTotalvenda() {
		return totalvenda;
	}
	public void setTotalvenda(double totalvenda) {
		this.totalvenda = totalvenda;
	}
    
    public void calculovendas (Vendedor v, Cliente  c, Produto p, double quant) {
    	
    	this.totalvenda = p.getValorvenda()*quant;
    	this.vendedor = v;
    	this.cliente = c;
    	this.produto = p;
    	this.codvenda += 1;
    	
    	
    }
    
	
}
