package br.etec.bean;

public class Fornecedor {
	 private int codigo;
	 private String nome;
	 private String endereco;
	 private String bairro;
	 private String complemento;
	 private String Cidade;
	 private String uf;
	 private String fone;
	 private String fonecel;
	 private String email;
	 private String cnpj;
	 private String inscest;
	 private String produto;
	 
	 
	public String getProduto() {
		return produto;
	}
	public void setProduto(String produto) {
		this.produto = produto;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
	public String getCidade() {
		return Cidade;
	}
	public void setCidade(String cidade) {
		Cidade = cidade;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	public String getFone() {
		return fone;
	}
	public void setFone(String fone) {
		this.fone = fone;
	}
	public String getFonecel() {
		return fonecel;
	}
	public void setFonecel(String fonecel) {
		this.fonecel = fonecel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getInscest() {
		return inscest;
	}
	public void setInscest(String inscest) {
		this.inscest = inscest;
	}
	 
	 

}
