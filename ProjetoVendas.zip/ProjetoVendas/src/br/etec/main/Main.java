package br.etec.main;

import br.etec.bean.Cliente;
import br.etec.bean.Fornecedor;
import br.etec.bean.Produto;
import br.etec.bean.Vendas;
import br.etec.bean.Vendedor;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Cliente c = new Cliente();
		c.setNome("Guido");
		c.setCodigo(1);
		c.setEmail("guido.branco@etec.sp.gov.br");
		
		Fornecedor f = new Fornecedor();
		f.setCodigo(1);
		f.setNome("Bebidas Legal");
		f.setProduto("Refrigerante guarana");
		
		
		Produto p = new Produto();
		p.fornecedor= f;
		p.setProduto(f.getProduto());
		p.setValor(5.00);
		p.calculovalorproduto(20);
		
		Vendedor v = new Vendedor();
		v.setCodigo(1);
		v.setNome("Guido");
		v.setSalario(1000);
		
		Vendas vend = new Vendas();
		vend.setCodvenda(1);
		vend.calculovendas(v, c, p, 2);
		System.out.println("Valor da venda = "+vend.getTotalvenda());
		
		v.calculocom(10,vend.getTotalvenda());
		v.salariototal();
		
		System.out.println("Salario final = "+v.getSalariofinal());
	
		

	}

}
